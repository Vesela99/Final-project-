﻿using System;
using System.Collections.Generic;

namespace Persistance.Models;

public partial class Role
{
    public int RoleId { get; set; }

    public string? RoleDesc { get; set; }
}
